﻿namespace authorization
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            entrence = new Button();
            exit = new Button();
            loginBox = new TextBox();
            passwordBox = new TextBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = SystemColors.ActiveCaptionText;
            label1.Font = new Font("Times New Roman", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label1.ForeColor = Color.Snow;
            label1.Location = new Point(32, 185);
            label1.Name = "label1";
            label1.Size = new Size(61, 21);
            label1.TabIndex = 0;
            label1.Text = "Логин";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = SystemColors.ActiveCaptionText;
            label2.Font = new Font("Times New Roman", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label2.ForeColor = Color.Snow;
            label2.Location = new Point(32, 275);
            label2.Name = "label2";
            label2.Size = new Size(69, 21);
            label2.TabIndex = 1;
            label2.Text = "Пароль";
            label2.Click += label2_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = SystemColors.ActiveCaptionText;
            label3.Font = new Font("Times New Roman", 27.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label3.ForeColor = Color.Snow;
            label3.Location = new Point(132, 46);
            label3.Name = "label3";
            label3.Size = new Size(219, 42);
            label3.TabIndex = 2;
            label3.Text = "Авторизация";
            // 
            // entrence
            // 
            entrence.BackColor = Color.Green;
            entrence.Font = new Font("Times New Roman", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            entrence.ForeColor = Color.Black;
            entrence.Location = new Point(32, 405);
            entrence.Name = "entrence";
            entrence.Size = new Size(167, 39);
            entrence.TabIndex = 3;
            entrence.Text = "Вход";
            entrence.UseVisualStyleBackColor = false;
            entrence.Click += entrance_Click;
            // 
            // exit
            // 
            exit.BackColor = Color.Red;
            exit.Font = new Font("Times New Roman", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            exit.ForeColor = Color.Black;
            exit.Location = new Point(32, 475);
            exit.Name = "exit";
            exit.Size = new Size(246, 42);
            exit.TabIndex = 4;
            exit.Text = "Завершение работы";
            exit.UseVisualStyleBackColor = false;
            exit.Click += exit_Click;
            // 
            // loginBox
            // 
            loginBox.Font = new Font("Times New Roman", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            loginBox.Location = new Point(99, 176);
            loginBox.Multiline = true;
            loginBox.Name = "loginBox";
            loginBox.Size = new Size(300, 30);
            loginBox.TabIndex = 5;
            // 
            // passwordBox
            // 
            passwordBox.Font = new Font("Times New Roman", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            passwordBox.Location = new Point(107, 266);
            passwordBox.Multiline = true;
            passwordBox.Name = "passwordBox";
            passwordBox.Size = new Size(300, 30);
            passwordBox.TabIndex = 6;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(484, 561);
            Controls.Add(passwordBox);
            Controls.Add(loginBox);
            Controls.Add(exit);
            Controls.Add(entrence);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Button entrence;
        private Button exit;
        private TextBox loginBox;
        private TextBox passwordBox;
    }
}
