namespace authorization
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void entrance_Click(object sender, EventArgs e)
        {
            if (loginBox.Text == "admin" && passwordBox.Text == "123")
            {
                MessageBox.Show("���� ��������!");
            }
            else
            {
                MessageBox.Show("������!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
